// Write a C program for the given flow chart in the right side. [Start , r = 23, V= (4/3)*(22/7)*r*r*r, print v, stop]
////MCE07905536 Shyed Shahriar
//Answer
#include <stdio.h>

int main() {
  int r = 23;
  float pi = 22.0f / 7.0f;
  float volume = (4.0f / 3.0f) * pi * r * r * r;

  printf("The volume of the sphere is %f\n", volume);
  getchar();
  return 0;
}
