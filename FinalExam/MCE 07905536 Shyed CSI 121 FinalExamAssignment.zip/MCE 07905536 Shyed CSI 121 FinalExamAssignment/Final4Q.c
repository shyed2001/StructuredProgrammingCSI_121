//Q:-
//Identify the errors in the right side C program segment.
//What will be its operations after correcting errors?
//int main<>
//{
//int number;
//char symbol;
//for (i= 1 ;i = 10; i--)
//    {
//        scanf("intial");
//        printf(symbol);
//        printf(/n);
//    }
//}
////MCE07905536 Shyed Shahriar
/// Answer:-
// Error corrected code

//int main<>
//{
 int main()
 {
int number;
char symbol;

//for (i= 1 ;i = 10; i--)
//    {
for (int i= 1 ;i <= 10; i++)

    //        scanf("intial");

{ scanf("%d", &number);
//        printf(symbol);

printf("%c", symbol=(char)number);
//        printf(/n);
printf( "\n");
 }

//return 0;
  }
//
//After Correction
//The provided C program prompts the user to enter 10 integers,
//then prints the ASCII character corresponding to each integer.




